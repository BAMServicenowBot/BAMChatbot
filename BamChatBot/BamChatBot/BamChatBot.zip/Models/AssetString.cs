﻿namespace BamChatBot.Models
{
    public class AssetString
    {
        public string Value { get; set; }
        public bool Required { get; set; }
    }
}