﻿namespace BamChatBot.Models
{
    public class AssetBool
    {
        public bool Value { get; set; }
        public bool Required { get; set; }
    }
}