﻿namespace BamChatBot.Models
{
    public class OU
    {
        public string name { get; set; }
        public string sys_id { get; set; }
        public string Id { get; set; }
    }
}