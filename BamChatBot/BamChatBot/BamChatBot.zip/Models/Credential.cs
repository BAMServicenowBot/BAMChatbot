﻿namespace BamChatBot.Models
{
    public class Credential
    {
        public string Value { get; set; }
        public bool Required { get; set; }
    }
}