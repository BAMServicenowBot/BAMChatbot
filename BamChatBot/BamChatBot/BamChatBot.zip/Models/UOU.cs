﻿namespace BamChatBot.Models
{
    public class UOU
    {
        public string U_id { get; set; }
    }
}