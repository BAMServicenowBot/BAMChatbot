﻿namespace BamChatBot.Models
{
    public class AssetInt
    {
        public double Value { get; set; }
        public bool Required { get; set; }
    }
}